<?php 
$nombre1 = mb_strtoupper($_POST['REG_Primer_Nombre']);
$nombre2 = mb_strtoupper($_POST['REG_Segundo_Nombre']);
$apellido1 = mb_strtoupper($_POST['REG_Primer_Apellido']);
$apellido2 = mb_strtoupper($_POST['REG_Segundo_Apellido']);
$documento = $_POST['REG_Documento'];

include "conexion.php";

$insertar = "INSERT INTO tb_reg_empleados (REG_Primer_Nombre, REG_Segundo_Nombre, REG_Primer_Apellido, REG_Segundo_Apellido, REG_Documento) VALUES ('$nombre1', '$nombre2', '$apellido1', '$apellido2', '$documento')";

if ($conexion -> query($insertar) == true) {
    header('location: ../registros.php');
}else{
    header('location: ../index.php');
}

$conexion -> close();
?>